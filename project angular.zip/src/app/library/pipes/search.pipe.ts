import { Pipe, PipeTransform } from '@angular/core';
import { Book } from '../book-details/book';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {
  booksArr:Book[]=[]
  i:number=0;

  transform(value: Book[], ...args: any[]): Book[] {

    value.forEach(element => {
      if(element.title.includes(args[0]))
      this.booksArr[this.i++]=element;
    });
    // for (let i = 0; i < Book.length; i++) {
    //  if(Book.)     
    //   return true;
    // } 
    //    return false;
    return this.booksArr;
  }


}
