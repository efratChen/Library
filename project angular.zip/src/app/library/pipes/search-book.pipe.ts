import { Pipe, PipeTransform } from '@angular/core';
import { Book } from '../book-details/book';

@Pipe({
  name: 'searchBook'
})
export class SearchBookPipe implements PipeTransform {
  //  i didnt understand at all :args[0]???
  books1: Book[] = [];
  transform(value: Book[], ...args: any[]): Book[] {
    this.books1 = [];
    for (const v of value) {
      // how can i do it shorter???
      if (v.author.toLowerCase().includes(args[0].toLowerCase()) ||
        v.id.toString().toLowerCase().includes(args[0].toLowerCase()) ||
        // ??v.pageCount.toString().includes(args[0].toString())||
        v.summary.toLowerCase().includes(args[0].toLowerCase()) ||
        v.title.toLowerCase().includes(args[0].toLowerCase()))
        this.books1.push(v);
    }
    return this.books1;
  }
}
// מה שעשיתי  בתחילה:1
// booksArr:Book[]=[]
//   i:number=0;

//   transform(value: Book[], ...args: any[]): Book[] {

//     value.forEach(element => {
//       if(element.title.includes(args[0]))
//       this.booksArr[this.i++]=element;
//     });

//     return this.booksArr;
//   }
// ניסיתי2
  // for (let i = 0; i < Book.length; i++) {
    //  if(Book.)     
    //   return true;
    // } 
    //    return false;