import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-review-excercise',
  templateUrl: './review-excercise.component.html',
  styleUrls: ['./review-excercise.component.css']
})
export class ReviewExcerciseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
