import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Book } from '../book-details/book';
import { BookDetailsComponent } from "../book-details/book-details.component";
import { Category } from '../category-list/category';
import { BookService } from '../services/book.service';
import { CategoryService } from '../services/category.service';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {

  abooks: Book[]=[];
  // ??מציג לי כל פעם את התוצאת חיפוש כתוספת לתוצאה הקודמת 
  //?? איך משנים זאת שלא יוסיף אלר ימחוק תקודם ויכתוב מחדש???
  // לא הבנתי למה הוא לא הציג את רשימת הספרים בכללל כי לא 
  // אתחלתי במחרוזת רייקה?? למה???
  // למה חייבים לאתחל במחרוזת רייקה?
  searchBook: string = "";
  // check(): void {
  //   if (this.search)
  //     alert("search result for " + this.search);
  // }
  constructor(private activatedRoute:ActivatedRoute, private bookService: BookService, private categoryService: CategoryService, private router: Router) {
    this.activatedRoute.params.subscribe(params=>
      this.bookService.getAll(params.name1).subscribe(b=>this.abooks=b));
   }
  getAllC: Category[] = null;

  ngOnInit(): void {
this.activatedRoute.params.subscribe(p=>this.bookService.getBookByCategory(p.id).subscribe(x=>this.abooks=x));
    // this.bookService.getAll().subscribe(res => {
    //   this.books = res;
    // });
    // this.categoryService.getAll().subscribe(res => {
    //   this.getAllC  = res;
    //   console.log("--- ",this.getAllC)
    // });

  }
  onClick(){
    this.router.navigate(['BookList'])
  }
  //   toContacts(){
  //     this.router.navigate(['BookDetailsComponent/']);
  // }
  // view book list according to category selected by user:
  // selectCategory() {
  //   this.router.navigate(['',{term:'a'}]);
  // }
}