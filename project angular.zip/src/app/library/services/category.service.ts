import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Category } from '../category-list/category';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categoryList: Category[] = [];

  api= "https://localhost:44305/api/category";

  constructor(public http: HttpClient) {
    console.log("from categories service");

  }



  //  ======== יכיל (כרגע) את רשימת  הקטגוריות
  // ========יכיל פונקציה getAll שתחזיר את רשימת הקטגוריות
  // ===========הקומפוננט categoryList ישתמש בו
  //  categoryList: Category[]=[
  //     new Category(13311,"children","üu","red"),
  //     new Category(1121,"22","üu","red"),
  //     new Category(1311,"ee","üu","red"),
  //     new Category(111,"eee","üu","red")
  //   ]
  // added:
  // getAll(){
  //   let categoryList =this.http.get<Category[]>("https://localhost:44305/api/category");
  //   return categoryList;
  // }


  // 
  getAll(): Observable<Category[]> {

    return this.http.get<Category[]>(this.api);
  }
  getCategory(id:number):Observable<Category>{
    return this.http.get<Category>(this.api+"/"+id);
  }

}
