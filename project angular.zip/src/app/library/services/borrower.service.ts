import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { log } from 'console';
import { Observable } from 'rxjs';
import { Borrower } from '../borrower-list/borrower';

@Injectable({
  // זה כמו לכתוב את הservice 
  // במערך ה provider 
  // root module ב
  providedIn: 'root'
})
export class BorrowerService {
  // ==========יכיל (כרגע) את רשימת השואלים----------------
  //============== יכיל פונקציה getAll שתחזיר את רשימת השואלים
  // ===========הקומפוננט borrowerList ישתמש בו
  BorrowerList: Borrower[] = [];
  api= 'https://localhost:44305/api/borrower';


  constructor(private http: HttpClient) {
    console.log("from borrower service");
    
  }
  getAll(): Observable<Borrower[]> {
    return this.http.get<Borrower[]>(this.api);
  }
  getBorrower(id: number):Observable< Borrower >{
        return this.http.get<Borrower>(this.api+"/"+id);
    }
  //  add a new borrower to the borower list:
  add(newBorrower: Borrower):Observable<Borrower> {
    console.log(newBorrower);
    debugger;

    return this.http.post<any>(this.api,newBorrower)
  }
  getName(id:number):string[]{
    let tmp:Borrower;
    let arr:string[]=[];
    this.getBorrower(id).subscribe(x=>tmp=x);
    if(tmp){
      arr[0]=tmp.firstName;
      arr[1]=tmp.lastName;

    }
    return arr;
  }
}
