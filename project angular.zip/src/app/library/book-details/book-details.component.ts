import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Category } from '../category-list/category';
// import { ActivatedRoute } from '@angular/router';
import { BookService } from '../services/book.service';
import { CategoryService } from '../services/category.service';
import { Book } from './book';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {
  //  לבדוק איך מכניסים ספר זה לרשימת הספרים -אם צריך
  // b=new Book(1,"In her death I have gotten my life","Menucha Bekerman"," as pecial story about 2 girls",2,30);
 isOversubtle(): boolean {
      return this.b.pageCount < 50 && this.b.ageCategory!=1;
    } 
// ,private activatedRoute:ActivatedRoute
  constructor(private bookService:BookService,private activatedRoute:ActivatedRoute,private categoryService:CategoryService) { }
  b:Book;
  c:Category;
  // getBook:Book=null;
  // num:number;  
  //?
  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params=>{
      this.bookService.getBook(params.id).subscribe(bd=>{
        this.b=bd;
        if(this.b){
          console.log("its err");
          
        };
        this.categoryService.getCategory(this.b.ageCategory).subscribe(c1=>{this.c=c1});
      })
    })
    //?
    // this.getBook=this.bookService.getBook("")

    // this.activatedRoute
  }
}
