import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-management',
  templateUrl: './sub-management.component.html',
  styleUrls: ['./sub-management.component.css']
})
export class SubManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
