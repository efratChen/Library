import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regulations-and-procedure',
  templateUrl: './regulations-and-procedure.component.html',
  styleUrls: ['./regulations-and-procedure.component.css']
})
export class RegulationsAndProcedureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
